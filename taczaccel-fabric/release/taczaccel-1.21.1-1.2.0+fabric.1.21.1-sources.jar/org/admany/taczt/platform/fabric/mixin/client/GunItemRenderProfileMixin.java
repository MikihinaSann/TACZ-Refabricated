package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.api.client.animation.statemachine.LuaAnimationStateMachine;
import com.tacz.guns.client.event.FirstPersonRenderGunEvent;
import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.renderer.item.GunItemRendererWrapper;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_811;
import org.admany.taczt.platform.fabric.client.GunRenderProfiler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {GunItemRendererWrapper.class}
)
public abstract class GunItemRenderProfileMixin {
   @Unique
   private long taczt$firstPersonStart;
   @Unique
   private long taczt$itemStart;

   @Inject(
      method = {"renderFirstPerson"},
      at = {@At("HEAD")},
      require = 1
   )
   private void taczt$beginFirstPerson(class_746 player, class_1799 stack, class_811 context, class_4587 poseStack, class_4597 buffers, int light, float partialTick, CallbackInfo callback) {
      this.taczt$firstPersonStart = GunRenderProfiler.begin();
   }

   @Inject(
      method = {"renderFirstPerson"},
      at = {@At("RETURN")},
      require = 1
   )
   private void taczt$endFirstPerson(class_746 player, class_1799 stack, class_811 context, class_4587 poseStack, class_4597 buffers, int light, float partialTick, CallbackInfo callback) {
      GunRenderProfiler.endFirstPerson(this.taczt$firstPersonStart);
   }

   @Inject(
      method = {"renderByItem"},
      at = {@At("HEAD")},
      require = 1,
      remap = true
   )
   private void taczt$beginItem(class_1799 stack, class_811 context, class_4587 poseStack, class_4597 buffers, int light, int overlay, CallbackInfo callback) {
      this.taczt$itemStart = GunRenderProfiler.begin();
   }

   @Inject(
      method = {"renderByItem"},
      at = {@At("RETURN")},
      require = 1,
      remap = true
   )
   private void taczt$endItem(class_1799 stack, class_811 context, class_4587 poseStack, class_4597 buffers, int light, int overlay, CallbackInfo callback) {
      GunRenderProfiler.endItem(this.taczt$itemStart);
   }

   @Redirect(
      method = {"lambda$renderFirstPerson$5"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/tacz/guns/api/client/animation/statemachine/LuaAnimationStateMachine;update()V"
),
      require = 1
   )
   private void taczt$profileAnimationUpdate(LuaAnimationStateMachine<?> machine) {
      long started = GunRenderProfiler.begin();
      machine.update();
      GunRenderProfiler.endAnimation(started);
   }

   @Redirect(
      method = {"lambda$renderFirstPerson$5"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/tacz/guns/client/event/FirstPersonRenderGunEvent;applyFirstPersonGunTransform(Lnet/minecraft/client/player/LocalPlayer;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/tacz/guns/client/model/BedrockGunModel;F)V"
),
      require = 1
   )
   private void taczt$profileFirstPersonTransform(class_746 player, class_1799 stack, class_4587 poseStack, BedrockGunModel model, float partialTick) {
      long started = GunRenderProfiler.begin();
      FirstPersonRenderGunEvent.applyFirstPersonGunTransform(player, stack, poseStack, model, partialTick);
      GunRenderProfiler.endTransform(started);
   }
}
