package org.admany.taczt.platform.fabric.client;

import java.util.ArrayDeque;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_7833;
import org.joml.Quaternionf;

public final class BedrockRotationPool {
   private static final int MAX_RETAINED = 64;
   private static final ThreadLocal<State> STATE = ThreadLocal.withInitial(State::new);

   private BedrockRotationPool() {
   }

   public static Quaternionf borrow(class_7833 axis, float angle) {
      State state = (State)STATE.get();
      if (axis != class_7833.field_40714 && axis != class_7833.field_40713 && axis != class_7833.field_40716 && axis != class_7833.field_40715 && axis != class_7833.field_40718 && axis != class_7833.field_40717) {
         return axis.rotation(angle);
      } else {
         Quaternionf rotation = (Quaternionf)state.available.pollFirst();
         if (rotation == null) {
            rotation = new Quaternionf();
         }

         if (axis == class_7833.field_40714) {
            rotation.rotationX(angle);
         } else if (axis == class_7833.field_40713) {
            rotation.rotationX(-angle);
         } else if (axis == class_7833.field_40716) {
            rotation.rotationY(angle);
         } else if (axis == class_7833.field_40715) {
            rotation.rotationY(-angle);
         } else if (axis == class_7833.field_40718) {
            rotation.rotationZ(angle);
         } else if (axis == class_7833.field_40717) {
            rotation.rotationZ(-angle);
         }

         state.borrowed.put(rotation, Boolean.TRUE);
         return rotation;
      }
   }

   public static void release(Quaternionf rotation) {
      State state = (State)STATE.get();
      if (state.borrowed.remove(rotation) != null && state.available.size() < 64) {
         state.available.offerFirst(rotation);
      }

   }

   public static void clear() {
      State state = (State)STATE.get();
      state.available.clear();
      state.borrowed.clear();
   }

   private static final class State {
      private final ArrayDeque<Quaternionf> available = new ArrayDeque();
      private final Map<Quaternionf, Boolean> borrowed = new IdentityHashMap();
   }
}
