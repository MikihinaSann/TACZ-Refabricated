package org.admany.taczt.platform.fabric.mixin.client;

import java.util.Deque;
import net.minecraft.class_4587;
import org.admany.taczt.platform.fabric.client.BedrockPoseStackPool;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_4587.class)
public abstract class PoseStackMixin {
    @Redirect(
            method = "popPose",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/Deque;removeLast()Ljava/lang/Object;"
            ),
            require = 1
    )
    private Object taczt$releasePose(Deque<?> stack) {
        Object removed = stack.removeLast();
        if (BedrockPoseStackPool.isActive() && removed instanceof class_4587.class_4665 pose) {
            BedrockPoseStackPool.release(pose);
        }
        return removed;
    }
}
