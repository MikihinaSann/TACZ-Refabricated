package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.client.model.BedrockGunModel;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import org.admany.taczt.platform.fabric.client.GunRenderProfiler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {BedrockGunModel.class}
)
public abstract class BedrockGunModelProfileMixin {
   @Unique
   private long taczt$modelStart;

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      require = 1
   )
   private void taczt$beginModel(class_4587 poseStack, class_1799 stack, class_811 context, class_1921 renderType, int light, int overlay, CallbackInfo callback) {
      this.taczt$modelStart = GunRenderProfiler.begin();
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")},
      require = 1
   )
   private void taczt$endModel(class_4587 poseStack, class_1799 stack, class_811 context, class_1921 renderType, int light, int overlay, CallbackInfo callback) {
      GunRenderProfiler.endModel(this.taczt$modelStart);
   }
}
