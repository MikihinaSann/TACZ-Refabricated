package org.admany.taczt.platform.fabric.client;

import net.minecraft.class_4587;

public final class AttachmentPoseStackPool {
   private static final ThreadLocal<State> LOCAL = ThreadLocal.withInitial(State::new);

   private AttachmentPoseStackPool() {
   }

   public static void enter() {
      ++((State)LOCAL.get()).depth;
   }

   public static class_4587 borrow() {
      State state = (State)LOCAL.get();
      int index = state.depth - 1;
      if (index < 0) {
         throw new IllegalStateException("Attachment pose stack was borrowed outside of its render scope");
      } else {
         if (index == state.stacks.length) {
            class_4587[] grown = new class_4587[state.stacks.length << 1];
            System.arraycopy(state.stacks, 0, grown, 0, state.stacks.length);
            state.stacks = grown;
         }

         class_4587 stack = state.stacks[index];
         if (stack == null) {
            stack = new class_4587();
            state.stacks[index] = stack;
         }

         reset(stack);
         return stack;
      }
   }

   public static void leave() {
      State state = (State)LOCAL.get();
      int index = --state.depth;
      if (index < 0) {
         state.depth = 0;
         throw new IllegalStateException("Attachment pose stack scope underflow");
      } else {
         reset(state.stacks[index]);
      }
   }

   public static void clear() {
      State state = (State)LOCAL.get();
      state.depth = 0;

      for(class_4587 stack : state.stacks) {
         if (stack != null) {
            reset(stack);
         }
      }

   }

   private static void reset(class_4587 stack) {
      while(!stack.method_22911()) {
         stack.method_22909();
      }

      stack.method_34426();
   }

   private static final class State {
      private class_4587[] stacks = new class_4587[4];
      private int depth;
   }
}
