package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.client.model.BedrockAttachmentModel;
import com.tacz.guns.client.model.functional.AttachmentRender;
import com.tacz.guns.client.renderer.item.AttachmentItemRenderer;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.util.RenderDistance;
import java.util.Optional;
import net.minecraft.class_1047;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import org.admany.taczt.platform.fabric.client.AttachmentPoseStackPool;
import org.admany.taczt.platform.fabric.client.BulletRenderLookupCache;
import org.admany.taczt.platform.fabric.client.GunRenderProfiler;
import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {AttachmentRender.class}
)
public abstract class AttachmentRenderMixin {
   @Unique
   private static long taczt$attachmentDeferredStarted;

   @Overwrite
   public static void renderAttachment(class_1799 attachment, class_1799 gun, class_4587 poseStack, class_811 context, int light, int overlay) {
      poseStack.method_22904((double)0.0F, (double)-1.5F, (double)0.0F);
      class_1792 var7 = attachment.method_7909();
      if (var7 instanceof IAttachment attachmentItem) {
         class_2960 attachmentId = attachmentItem.getAttachmentId(attachment);
         Optional<ClientAttachmentIndex> index = BulletRenderLookupCache.getAttachmentIndex(attachmentId);
         if (index.isPresent()) {
            ClientAttachmentIndex clientIndex = (ClientAttachmentIndex)index.get();
            BedrockAttachmentModel model = clientIndex.getAttachmentModel();
            class_2960 texture = clientIndex.getModelTexture();
            if (model != null && texture != null) {
               Pair<BedrockAttachmentModel, class_2960> lodModel = clientIndex.getLodModel();
               if (lodModel != null && !RenderDistance.inRenderHighPolyModelDistance(poseStack) && !context.method_29998()) {
                  model = (BedrockAttachmentModel)lodModel.getLeft();
                  texture = (class_2960)lodModel.getRight();
               }

               long started = GunRenderProfiler.begin();
               model.render(attachment, gun, poseStack, context, class_1921.method_23576(texture), light, overlay);
               GunRenderProfiler.endAttachmentModel(started);
            }
         } else {
            class_4597.class_4598 source = class_310.method_1551().method_22940().method_23000();
            class_4588 consumer = source.getBuffer(class_1921.method_23580(class_1047.method_4539()));
            long started = GunRenderProfiler.begin();
            AttachmentItemRenderer.SLOT_ATTACHMENT_MODEL.method_60879(poseStack, consumer, light, overlay);
            GunRenderProfiler.endAttachmentFallback(started);
         }
      }
   }

   @Inject(
      method = {"lambda$render$2"},
      at = {@At("HEAD")},
      require = 1
   )
   private void taczt$beginAttachmentPoseScope(CallbackInfo callback) {
      taczt$attachmentDeferredStarted = GunRenderProfiler.begin();
      AttachmentPoseStackPool.enter();
   }

   @Inject(
      method = {"lambda$render$2"},
      at = {@At("RETURN")},
      require = 1
   )
   private void taczt$endAttachmentPoseScope(CallbackInfo callback) {
      AttachmentPoseStackPool.leave();
      GunRenderProfiler.endAttachmentDeferred(taczt$attachmentDeferredStarted);
   }

   @Redirect(
      method = {"lambda$render$2"},
      at = @At(
   value = "NEW",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;"
),
      require = 1
   )
   private class_4587 taczt$borrowAttachmentPoseStack() {
      return AttachmentPoseStackPool.borrow();
   }
}
