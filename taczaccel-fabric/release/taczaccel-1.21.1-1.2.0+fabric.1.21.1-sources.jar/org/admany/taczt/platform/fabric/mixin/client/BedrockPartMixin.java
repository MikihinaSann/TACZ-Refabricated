package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.client.model.bedrock.BedrockPart;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_811;
import org.admany.taczt.platform.fabric.client.BedrockPoseStackPool;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {BedrockPart.class}
)
public abstract class BedrockPartMixin {
   private static final String TACZT$FULL_RENDER = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V";
   @Shadow
   public boolean visible;

   @Inject(
      method = {"render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 1
   )
   private void taczt$skipHiddenPart(class_4587 poseStack, class_811 context, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha, CallbackInfo callbackInfo) {
      if (!this.visible) {
         callbackInfo.cancel();
      }

   }

   @Redirect(
      method = {"render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V"
),
      require = 1,
      remap = true
   )
   private void taczt$enterPooledPoseScope(class_4587 poseStack) {
      BedrockPoseStackPool.enter();
      poseStack.method_22903();
   }

   @Redirect(
      method = {"render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"
),
      require = 1,
      remap = true
   )
   private void taczt$leavePooledPoseScope(class_4587 poseStack) {
      poseStack.method_22909();
      BedrockPoseStackPool.leave();
   }

   @Redirect(
      method = {"translateAndRotateAndScale"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V",
   ordinal = 0
),
      require = 1,
      remap = true
   )
   private void taczt$skipZeroAnimationOffset(class_4587 poseStack, float x, float y, float z) {
      if (x != 0.0F || y != 0.0F || z != 0.0F) {
         poseStack.method_46416(x, y, z);
      }

   }

   @Redirect(
      method = {"translateAndRotateAndScale"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V",
   ordinal = 1
),
      require = 1,
      remap = true
   )
   private void taczt$skipZeroBoneTranslation(class_4587 poseStack, float x, float y, float z) {
      if (x != 0.0F || y != 0.0F || z != 0.0F) {
         poseStack.method_46416(x, y, z);
      }

   }

   @Redirect(
      method = {"translateAndRotateAndScale"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lorg/joml/Quaternionf;)V",
   ordinal = 3
),
      require = 1,
      remap = true
   )
   private void taczt$skipIdentityAdditionalRotation(class_4587 poseStack, Quaternionf rotation) {
      if (rotation.x != 0.0F || rotation.y != 0.0F || rotation.z != 0.0F || rotation.w != 1.0F) {
         poseStack.method_22907(rotation);
      }

   }

   @Redirect(
      method = {"translateAndRotateAndScale"},
      at = @At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;scale(FFF)V"
),
      require = 1,
      remap = true
   )
   private void taczt$skipIdentityScale(class_4587 poseStack, float x, float y, float z) {
      if (x != 1.0F || y != 1.0F || z != 1.0F) {
         poseStack.method_22905(x, y, z);
      }

   }
}
