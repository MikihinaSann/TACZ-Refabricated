package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.client.gui.overlay.GunHudOverlay;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(
   value = {GunHudOverlay.class}
)
public abstract class GunHudOverlayMixin {
   @Unique
   private static String taczt$version;
   @Unique
   private static String taczt$versionLabel;

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)I"
),
      require = 1,
      remap = true
   )
   private int taczt$drawTweaksVersion(class_332 graphics, class_327 font, String baseVersion, int x, int y, int color) {
      int result = graphics.method_25303(font, baseVersion, x, y + 2, color);
      graphics.method_25303(font, taczt$versionLabel(), x, y + 14, color);
      return result;
   }

   @Unique
   private static String taczt$version() {
      if (taczt$version == null) {
         taczt$version = FabricLoader.getInstance().getModContainer("taczaccelerated")
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse("unknown");
      }

      return taczt$version;
   }

   @Unique
   private static String taczt$versionLabel() {
      if (taczt$versionLabel == null) {
         taczt$versionLabel = "[TaCZ:Accel] " + taczt$version();
      }

      return taczt$versionLabel;
   }
}
