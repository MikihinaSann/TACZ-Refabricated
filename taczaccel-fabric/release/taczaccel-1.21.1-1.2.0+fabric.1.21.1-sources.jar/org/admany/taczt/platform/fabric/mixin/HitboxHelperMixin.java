package org.admany.taczt.platform.fabric.mixin;

import com.tacz.guns.api.entity.ITargetEntity;
import com.tacz.guns.util.HitboxHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {HitboxHelper.class}
)
public abstract class HitboxHelperMixin {
   @Inject(
      method = {"getFixedBoundingBox"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 1
   )
   private static void taczt$reuseNonPlayerMotion(class_1297 target, class_1297 shooter, CallbackInfoReturnable<class_238> callback) {
      if (!(target instanceof class_1657)) {
         double x = target.method_23317() - target.field_6014;
         double y = target.method_23318() - target.field_6036;
         double z = target.method_23321() - target.field_5969;
         class_238 bounds = target.method_5829().method_1012(x, y, z);
         if (target.method_5854() != null || target instanceof ITargetEntity) {
            bounds = bounds.method_989((double)-2.5F * x, (double)-2.5F * y, (double)-2.5F * z);
         }

         callback.setReturnValue(bounds.method_989((double)-5.0F * x, (double)-5.0F * y, (double)-5.0F * z));
      }
   }
}
