package org.admany.taczt.platform.fabric.mixin.client;

import com.tacz.guns.client.model.BedrockAmmoModel;
import com.tacz.guns.client.model.bedrock.BedrockModel;
import com.tacz.guns.client.renderer.entity.EntityBulletRenderer;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.index.ClientAmmoIndex;
import com.tacz.guns.entity.EntityKineticBullet;
import java.util.Optional;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.admany.taczt.platform.fabric.client.BulletModelCache;
import org.admany.taczt.platform.fabric.client.BulletRenderLookupCache;
import org.admany.taczt.platform.fabric.client.BulletRenderTypeCache;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {EntityBulletRenderer.class}
)
public abstract class EntityBulletRendererMixin {
   @Shadow
   public abstract void renderTracerAmmo(EntityKineticBullet var1, float[] var2, float var3, class_4587 var4, int var5);

   @Inject(
      method = {"getModel"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 1,
      remap = false
   )
   private static void taczt$reuseDefaultBulletModel(CallbackInfoReturnable<Optional<BedrockModel>> callback) {
      BedrockModel cached = BulletModelCache.get();
      if (cached != null) {
         callback.setReturnValue(Optional.of(cached));
      }

   }

   @Inject(
      method = {"getModel"},
      at = {@At("RETURN")},
      require = 1,
      remap = false
   )
   private static void taczt$cacheDefaultBulletModel(CallbackInfoReturnable<Optional<BedrockModel>> callback) {
      callback.getReturnValue().ifPresent(BulletModelCache::set);
   }

   @Overwrite
   public void render(EntityKineticBullet bullet, float yaw, float partialTick, class_4587 poseStack, class_4597 buffers, int light) {
      Optional<GunDisplayInstance> display = BulletRenderLookupCache.getGunDisplay(bullet.getGunDisplayId(), bullet.getGunId());
      if (!display.isEmpty()) {
         float[] tracerColor = (float[])bullet.getTracerColorOverride().orElse(((GunDisplayInstance)display.get()).getTracerColor());
         Optional<ClientAmmoIndex> ammoIndex = BulletRenderLookupCache.getAmmoIndex(bullet.getAmmoId());
         if (!ammoIndex.isEmpty()) {
            ClientAmmoIndex index = (ClientAmmoIndex)ammoIndex.get();
            BedrockAmmoModel model = index.getAmmoEntityModel();
            class_2960 texture = index.getAmmoEntityTextureLocation();
            if (model != null && texture != null) {
               poseStack.method_22907(class_7833.field_40716.rotationDegrees(class_3532.method_16439(partialTick, bullet.field_5982, bullet.method_36454()) - 180.0F));
               poseStack.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_16439(partialTick, bullet.field_6004, bullet.method_36455())));
               poseStack.method_22903();
               poseStack.method_22904((double)0.0F, (double)1.5F, (double)0.0F);
               poseStack.method_22905(-1.0F, -1.0F, 1.0F);
               model.render(poseStack, class_811.field_4318, class_1921.method_23689(texture), light, class_4608.field_21444);
               poseStack.method_22909();
            }

            if (bullet.isTracerAmmo()) {
               float[] indexTracerColor = index.getTracerColor();
               this.renderTracerAmmo(bullet, indexTracerColor != null ? indexTracerColor : tracerColor, partialTick, poseStack, light);
            }

         }
      }
   }

   @Redirect(
      method = {"lambda$renderTracerAmmo$1"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/RenderType;energySwirl(Lnet/minecraft/resources/ResourceLocation;FF)Lnet/minecraft/client/renderer/RenderType;"
),
      require = 1,
      remap = true
   )
   private class_1921 taczt$reuseTracerRenderType(class_2960 texture, float uOffset, float vOffset) {
      return BulletRenderTypeCache.tracerEnergySwirl(texture, uOffset, vOffset);
   }
}
