package org.admany.taczt.platform.fabric.client;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

public final class BulletRenderTypeCache {
   private static final int MAX_ENTRIES = 64;
   private static final Map<Key, class_1921> TRACER_TYPES = new LinkedHashMap<Key, class_1921>(16, 0.75F, true) {
      protected boolean removeEldestEntry(Map.Entry<Key, class_1921> eldest) {
         return this.size() > 64;
      }
   };

   private BulletRenderTypeCache() {
   }

   public static class_1921 tracerEnergySwirl(class_2960 texture, float uOffset, float vOffset) {
      Key key = new Key(texture, Float.floatToIntBits(uOffset), Float.floatToIntBits(vOffset));
      synchronized(TRACER_TYPES) {
         class_1921 cached = (class_1921)TRACER_TYPES.get(key);
         if (cached != null) {
            return cached;
         } else {
            class_1921 created = class_1921.method_23018(texture, uOffset, vOffset);
            TRACER_TYPES.put(key, created);
            return created;
         }
      }
   }

   public static void clear() {
      synchronized(TRACER_TYPES) {
         TRACER_TYPES.clear();
      }
   }

   private static record Key(class_2960 texture, int uOffset, int vOffset) {
   }
}
